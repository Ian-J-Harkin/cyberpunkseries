import os
from langgraph.checkpoint.sqlite import SqliteSaver
from graph import build_graph

def run():
    builder = build_graph()
    
    # Setup persistent memory
    db_path = os.path.join(os.path.dirname(__file__), "checkpoints.sqlite")
    
    with SqliteSaver.from_conn_string(db_path) as memory:
        graph = builder.compile(checkpointer=memory)
        
        # Initial config for checkpointer
        config = {"configurable": {"thread_id": "warm_neon_session_1"}}
        
        # Initial State
        initial_state = {
            "vault_access_level": 0, # Drafter won't get the real compass
            "fraying_level": "High (Neon decay, acid rain)",
            "current_location": "The Sprawl",
            "inventory_log": [],
            "cast_matrix": [
                {
                    "name": "Sarge",
                    "internal_frequency": "Cynical realism",
                    "noticing_rule": "Sarge notices the protagonist's biometric errors",
                    "physical_anchor": "Scuffed cybernetic arm",
                    "trust_level": 50
                }
            ],
            "beats": [],
            "current_beat_index": 0,
            "draft_prose": ""
        }
        
        print("Starting the Warm Neon Engine...")
        
        try:
            # We use stream to observe intermediate state outputs
            for event in graph.stream(initial_state, config):
                for node, state_update in event.items():
                    print(f"\n--- Node: {node} ---")
                    if "north_star" in state_update:
                        print(f"North Star Updated: {state_update['north_star']}")
                    if "beats" in state_update:
                        print(f"Generated {len(state_update['beats'])} beats.")
                    if "draft_prose" in state_update:
                        print("Draft Prose Updated (excerpt):")
                        print(state_update["draft_prose"][:200] + "...")
                        
        except Exception as e:
            print(f"Execution failed: {e}")
            print("\nNote: Make sure OPENROUTER_API_KEY or GEMINI_API_KEY is set in your environment variables.")

if __name__ == "__main__":
    run()
