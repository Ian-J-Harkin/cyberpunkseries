from typing import Literal
from langgraph.graph import StateGraph, START, END
from state import State
from nodes import (
    dna_architect,
    scene_plotter,
    persona_drafter,
    continuity_extractor
)

# Define conditional edge logic
def vault_access_edge(state: State) -> Literal["persona_drafter"]:
    # The condition is handled in persona_drafter by checking vault_access_level
    # but we represent the flow here
    return "persona_drafter"

def should_continue(state: State) -> Literal["persona_drafter", END]:
    current_beats = state.get("beats", [])
    index = state.get("current_beat_index", 0)
    
    if index < len(current_beats):
        return "persona_drafter"
    
    return END

def build_graph():
    builder = StateGraph(State)

    # 1. Add nodes
    builder.add_node("dna_architect", dna_architect)
    builder.add_node("scene_plotter", scene_plotter)
    builder.add_node("persona_drafter", persona_drafter)
    builder.add_node("continuity_extractor", continuity_extractor)

    # 2. Add edges
    # Connect START to dna_architect
    builder.add_edge(START, "dna_architect")
    
    # Connect architect to plotter
    builder.add_edge("dna_architect", "scene_plotter")
    
    # Conditional logic / Vault access gating before drafting
    builder.add_conditional_edges(
        "scene_plotter",
        vault_access_edge,
    )
    
    # Connect drafter to extractor
    builder.add_edge("persona_drafter", "continuity_extractor")
    
    # Loop over beats
    builder.add_conditional_edges(
        "continuity_extractor",
        should_continue,
    )

    return builder
