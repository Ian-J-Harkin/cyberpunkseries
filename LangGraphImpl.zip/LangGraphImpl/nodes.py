import os
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from state import State

# Utility to load prompts from Knowledge Base
def load_prompt(filename: str) -> str:
    path = os.path.join(os.path.dirname(__file__), "prompts", filename)
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()

# Initialize LLM based on available keys
if os.environ.get("GEMINI_API_KEY"):
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-pro",
        temperature=0.7,
        google_api_key=os.environ.get("GEMINI_API_KEY")
    )
else:
    llm = ChatOpenAI(
        model="openai/gpt-4o", # OpenRouter model routing syntax
        base_url="https://openrouter.ai/api/v1",
        api_key=os.environ.get("OPENROUTER_API_KEY", ""),
        temperature=0.7
    )

def dna_architect(state: State) -> dict:
    prompt = load_prompt("dna_architect.txt")
    
    # Inform the architect of the current state
    context = f"Current Fraying Level: {state.get('fraying_level', 'Unknown')}\nCurrent Location: {state.get('current_location', 'Unknown')}"
    
    messages = [
        SystemMessage(content=prompt),
        HumanMessage(content=f"Initialize the narrative DNA.\n{context}")
    ]
    response = llm.invoke(messages)
    
    # In a fully robust system, we would parse structured output here.
    # For now, we assume the LLM output provides updates to north_star and world_compass.
    return {
        "north_star": "Determined by DNA Architect: " + response.content[:50] + "...",
        "world_compass": "Set by DNA Architect"
    }

def scene_plotter(state: State) -> dict:
    prompt = load_prompt("scene_plotter.txt")
    
    messages = [
        SystemMessage(content=prompt),
        HumanMessage(content="Generate the next set of beats.")
    ]
    response = llm.invoke(messages)
    
    # Split response into conceptual beats (mock implementation)
    beats = [beat for beat in response.content.split("\n") if beat.strip()]
    
    return {
        "beats": beats,
        "current_beat_index": 0
    }

def persona_drafter(state: State) -> dict:
    prompt = load_prompt("persona_drafter.txt")
    
    # Apply The Vault Condition Matrix before drafting
    current_compass = state.get("world_compass", "")
    
    if state.get("vault_access_level", 0) < 1:
        # Mask the World Compass
        current_compass = "Industrial Rumors (Computational Drift/Mineral Euphoria are hidden)."
        
    current_beats = state.get("beats", [])
    beat_index = state.get("current_beat_index", 0)
    current_beat = current_beats[beat_index] if beat_index < len(current_beats) else "No beat available."
    
    messages = [
        SystemMessage(content=prompt),
        HumanMessage(content=f"Draft prose for this beat: {current_beat}\nWorld Compass Context: {current_compass}")
    ]
    
    response = llm.invoke(messages)
    
    # Append the new draft
    current_draft = state.get("draft_prose", "")
    new_draft = current_draft + "\n\n" + response.content
    
    return {
        "draft_prose": new_draft.strip()
    }

def continuity_extractor(state: State) -> dict:
    prompt = load_prompt("continuity_extractor.txt")
    
    latest_draft = state.get("draft_prose", "")
    
    messages = [
        SystemMessage(content=prompt),
        HumanMessage(content=f"Analyze the latest prose and extract continuity updates.\nProse:\n{latest_draft}")
    ]
    
    response = llm.invoke(messages)
    
    # Ideally, we parse JSON here to get exact inventory/cast updates.
    # We will just return the state as is for now with an incremented beat index.
    return {
        "current_beat_index": state.get("current_beat_index", 0) + 1
    }
