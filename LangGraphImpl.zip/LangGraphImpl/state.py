import operator
from typing import TypedDict, List, Annotated

class SupportingCast(TypedDict):
    name: str
    internal_frequency: str
    noticing_rule: str
    physical_anchor: str
    trust_level: int

class State(TypedDict):
    """The Continuity Log - Central repository of truth"""
    # Vault / Access
    vault_access_level: int
    
    # World
    fraying_level: str
    north_star: str
    world_compass: str
    
    # Location
    current_location: str
    
    # Character
    inventory_log: List[str]
    cast_matrix: List[SupportingCast]
    
    # Narrative Generation
    # Using Annotated and operator.add allows us to append to the beats/prose optionally, 
    # but since this is a draft, we might just overwrite or manage carefully.
    # For now, we will simply overwrite lists or assume nodes manage them.
    beats: List[str]
    current_beat_index: int
    draft_prose: str
